import pgzrun
import random
import asyncio

# === Configuración ===
TITLE = "Angry Flap: Bird Flight"
WIDTH = 600
HEIGHT = 499

# === Actores ===
pajaro = Actor("pajaro", (150, 250))
pajaro2 = Actor("pajaro2", (300, 250))
pajaro3 = Actor("pajaro3", (450, 250))

fondo = Actor("fondoancho", center=(WIDTH // 2, HEIGHT // 2))
piso1 = Actor("piso", (200, HEIGHT - 50))
piso2 = Actor("piso", (600, HEIGHT - 50)) # Posicionado al lado del primero

tuboA = Actor("tubo_verde_arriba", (700, -50))
tuboB = Actor("tubo_verde_abajo", (700, 500))

boton_menu = Actor("boton_menu", center=(300, 420))
boton_ok = Actor("boton_ok", center=(300, 420))
boton_getready = Actor("boton_getready", center=(300, 100))
boton_tap = Actor("boton_tap", center=(300, 200))
boton_gameover = Actor("boton_gameover", center=(300, 200))
logo_monedas = Actor("logo_monedas", topleft=(10, 10))
numero_actual = Actor("0", topleft=(38, 15))

# === Variables ===
personaje_actual = "pajaro"
velocidad = 0
gravedad = 0.5
salto = -8
count = 0
pasado = False
mode = "menu"

def reset_game():
    global velocidad, count, pasado, mode
    pajaro.y = 250
    velocidad = 0
    tuboA.x = 700
    tuboA.y = random.randint(-120, 80)
    tuboB.x = 700
    tuboB.y = tuboA.y + 550
    count = 0
    numero_actual.image = "0"
    pasado = False
    pajaro.image = personaje_actual

def movimientoTuberias():
    global pasado
    tuboA.x -= 4
    tuboB.x -= 4
    if tuboA.x <= -70:
        tuboA.x = 700
        tuboA.y = random.randint(-120, 40)
        tuboB.x = 700
        tuboB.y = tuboA.y + 550
        pasado = False

def movimientoPiso():
    piso1.x -= 2
    piso2.x -= 2
    if piso1.right < 0:
        piso1.x = piso2.right + (piso1.width / 2)
    if piso2.right < 0:
        piso2.x = piso1.right + (piso2.width / 2)

def conteoMonedas():
    global pasado, count
    if tuboA.x < pajaro.x and not pasado:
        count += 1
        pasado = True
        if count <= 9:
            numero_actual.image = str(count)

def colisiones():
    global mode 
    if pajaro.colliderect(tuboA) or pajaro.colliderect(tuboB) or pajaro.colliderect(piso1) or pajaro.colliderect(piso2):
        mode = "game_over"

def draw():
    fondo.draw()
    if mode == "menu":
        pajaro.draw()
        piso1.draw()
        piso2.draw()
        boton_getready.draw()
        boton_menu.draw()
        boton_tap.draw()
    elif mode == "game":
        tuboA.draw()
        tuboB.draw()
        piso1.draw()
        piso2.draw()
        logo_monedas.draw()
        numero_actual.draw()
        pajaro.draw()
    elif mode == "game_over":
        tuboA.draw()
        tuboB.draw()
        piso1.draw()
        piso2.draw()
        boton_gameover.draw()
        boton_menu.draw()
        logo_monedas.draw()
        numero_actual.draw()
        pajaro.draw()
    elif mode == "coleccion":
        boton_ok.draw()
        pajaro.draw()
        pajaro2.draw()
        pajaro3.draw()

def update(dt):
    global velocidad, mode
    if mode == "game":
        velocidad += gravedad
        pajaro.y += velocidad
        movimientoTuberias()
        movimientoPiso()
        conteoMonedas()
        colisiones()
    
    if pajaro.y > HEIGHT:
        mode = "game_over"
    if pajaro.y < 0:
        pajaro.y = 0

def on_mouse_down(pos):
    global velocidad, mode, personaje_actual
    if mode == "menu":
        if boton_tap.collidepoint(pos):
            mode = "game"
        elif boton_menu.collidepoint(pos):
            mode = "coleccion"
    elif mode == "game":
        velocidad = salto
    elif mode == "game_over":
        if boton_menu.collidepoint(pos):
            reset_game()
            mode = "menu"
    elif mode == "coleccion":
        if boton_ok.collidepoint(pos):
            mode = "menu"
        elif pajaro.collidepoint(pos):
            personaje_actual = "pajaro"
        elif pajaro2.collidepoint(pos):
            personaje_actual = "pajaro2"
        elif pajaro3.collidepoint(pos):
            personaje_actual = "pajaro3"
        pajaro.image = personaje_actual

# === Lógica para Web (GitHub.io) ===
async def main():
    pgzrun.go()
    await asyncio.sleep(0)

if __name__ == "__main__":
    asyncio.run(main())